let appsConfigFn = () => {};

export { appsConfigFn };
