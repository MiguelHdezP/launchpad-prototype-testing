import axios from "axios";
import { useState } from "react";

const url = "url";

export const getLaunchPadData = () => {
  // const { x, y } = useState([]);
  axios.get(url);
};
