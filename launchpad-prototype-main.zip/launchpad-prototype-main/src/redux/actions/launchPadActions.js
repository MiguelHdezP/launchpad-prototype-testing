import * as api from "../api";
import { ActionTypes } from "../constants/action-types";

export const getData = () => async (dispatch) => {
  try {
    dispatch({ type: ActionTypes.GET_MOVIES, payload: xyz });
  } catch (error) {
    //console.log(error.message);
  }
};
