import { combineReducers } from "redux";

const reducers = combineReducers({
  x: y,
});

export default reducers;
