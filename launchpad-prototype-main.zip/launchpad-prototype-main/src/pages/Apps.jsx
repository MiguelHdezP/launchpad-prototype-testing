import React, { useState, useEffect } from "react";
import ContentContainer from "../components/content-container/ContentContainer";
import SectionHeader from "../components/section-header/SectionHeader";
import Form from "../components/form-elements/Form";
import FieldSet from "../components/form-elements/FieldSet";
import InputFilter from "../components/inputFilter/InputFilter";
import ApplicationsContainer from "../components/applications-container/ApplicationsContainer";
import MockAppsData from "../context/mockData.json";
//<></>  </>
export default function Apps(props) {
  const { fnConfig, dataNoData, filterFlag } = props;
  const fakeData = MockAppsData.slice(0, dataNoData);
  const [payLoadData, setPayLoadData] = useState("");
  const [searchApps, setSearchApp] = useState("");
  const filterData = () => {
    return fakeData.filter((data) => {
      if (searchApps === "" || searchApps === " ") {
        return data;
      } else if (
        data.appName.toLowerCase().includes(searchApps.toLocaleLowerCase())
      ) {
        return data;
      }
    });
  };

  useEffect(() => {
    let newData = filterData();
    setPayLoadData(newData);
  }, [searchApps, dataNoData]);

  const inputFn = (value) => {
    setSearchApp(value);
  };

  return (
    <ContentContainer>
      <SectionHeader sectionText="Classic Applications" />
      {dataNoData > 15 ? (
        <Form>
          <FieldSet classFieldset="app-filtering">
            <InputFilter inputFn={inputFn} fnToggle={fnConfig} />
          </FieldSet>
        </Form>
      ) : (
        ""
      )}
      {dataNoData > 15 ? <div className="divider"></div> : ""}
      <ApplicationsContainer
        appsPayload={fakeData.length ? payLoadData : []}
        classAppContainer="citrix-apps"
        customClass={dataNoData > 15 ? "" : "citrix-apps-extraPadding"}
        filterFlag={filterFlag}
      />
    </ContentContainer>
  );
}
