import React from "react";
import "./SectionHeader.scss";

export default function SectionHeader(props) {
  const { sectionText } = props;
  return (
    <section id="js-section-header" className="section-header">
      {sectionText}
    </section>
  );
}
