import React from "react";

export default function buckets() {
  return <div>buckets</div>;
}
