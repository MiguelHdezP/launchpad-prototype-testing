import React from "react";
import "./ContentContainer.scss";

export default function ContentContainer(props) {
  return (
    <section id="js-content-container" className="content-container">
      {props.children}
    </section>
  );
}
