import React from "react";
import "./Login.scss";

export default function Login() {
  return <div>Login</div>;
}
