import React from "react";
import "./ContainerLoader.scss";

export default function ContainerLoader() {
  return <div>ContainerLoader</div>;
}
