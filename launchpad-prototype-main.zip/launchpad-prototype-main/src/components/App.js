import React, { useState } from "react";
import "../styles/layout.scss";
import "../styles/base.scss";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Today from "../pages/Today";
import Apps from "../pages/Apps";
import Protocols from "../pages/Protocols";
import Search from "../pages/Search";
import ErrorPage from "../pages/ErrorPage";
import Reports from "../pages/Reports";
import Settings from "../pages/Settings";
import Announcements from "../pages/Announcements";
import Messages from "../pages/Messages";
import Ddashboard from "../pages/Ddashboard";
import ApplicationHeader from "./application-header/ApplicationHeader";
import Container from "./container/Container";
import Tabs from "./tabs/Tabs";
import ConfigurationSideBar from "./configuration-side-bar/ConfigurationSideBar";

//<></>  </>
export default function App() {
  const [sidebar, setSidebar] = useState(false);
  const [dataNoData, setDataNoData] = useState(0);
  const [fnConfig, setFnConfig] = useState(true);
  const [filterFlag, setFilterFlag] = useState(false);
  const [checkedIf, setCheckedIf] = useState(true);
  const [visibleTabs, setVisibleTabs] = useState([2, 9]);
  const showSidebar = () => setSidebar(!sidebar);
  const hideSidebar = () => setSidebar(false);

  const appsToBeDisplayed = (value) => {
    setDataNoData(value);
    if (value == 0) setFilterFlag(false);
    else setFilterFlag(true);
  };
  const toggleSearchAppsFn = (value) => {
    if (value == 1) setFnConfig(false);
    else if (value == 2) setFnConfig(true);
  };
  const turnOnOffTabs = (value, checked) => {
    let tabsToDisplay = [];
    if (checked) {
      tabsToDisplay = [...visibleTabs, value].sort((a, b) => a - b);
    } else {
      tabsToDisplay = visibleTabs.filter((e) => {
        if (e !== value) {
          return true;
        }
      });
    }
    setCheckedIf(checked);
    setVisibleTabs(tabsToDisplay);
  };

  return (
    <>
      <ApplicationHeader />
      <Container>
        <Router>
          <ConfigurationSideBar
            toggleSideBar={showSidebar}
            sidebarVisible={sidebar}
            toggleSearchAppsFn={toggleSearchAppsFn}
            appsToBeDisplayed={appsToBeDisplayed}
          />
          <Tabs
            toggleSideBar={hideSidebar}
            visibleTabs={visibleTabs}
            checked={checkedIf}
          />
          <Routes>
            <Route
              path="/"
              element={
                <Apps
                  fnConfig={fnConfig}
                  dataNoData={dataNoData}
                  filterFlag={filterFlag}
                />
              }
            />
            <Route path="/today" element={<Today />} />
            <Route path="/protocols" element={<Protocols />} />
            <Route path="/announcements" element={<Announcements />} />
            <Route path="/messages" element={<Messages />} />
            <Route path="/ddashboard" element={<Ddashboard />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/search" element={<Search />} />
            <Route
              path="/settings"
              element={<Settings turnOnOffTabs={turnOnOffTabs} />}
            />
            <Route path="*" element={<ErrorPage />} />
          </Routes>
        </Router>
      </Container>
    </>
  );
}
