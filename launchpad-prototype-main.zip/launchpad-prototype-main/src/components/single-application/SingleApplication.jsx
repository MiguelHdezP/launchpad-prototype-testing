import React from "react";
import "./SingleApplication.scss";
//<></>  </>
export default function SingleApplication(props) {
  const { appName, appIcon } = props;
  let openNewWindow = () =>
    window.open("https://wiki.cerner.com/", "_blank", "noopener,noreferrer");
  return (
    <div
      id="js-single-application"
      className="single-application"
      onClick={() => openNewWindow()}
    >
      {appIcon ? (
        <img src="appIcon" alt={appName} />
      ) : (
        <div className="single-application-dummy"></div>
      )}
      <label>{appName}</label>
    </div>
  );
}
