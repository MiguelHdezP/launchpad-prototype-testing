import React, { useState } from "react";
import "./PageConfigurations.scss";
//<></>  </>
export const ConfigToday = (props) => {
  return <div>Hello</div>;
};

export const ConfigApps = (props) => {
  const { toggleSearchAppsFn, appsToBeDisplayed } = props;
  const [pickSearch, setPickSearch] = useState(2);
  const [appsNumber, setAppsNumber] = useState(0);
  const [btnDataSend, BtnDataSend] = useState(true);
  const [txtBtn, setTxtBtn] = useState("Apply");

  const handleRadioClick = (e) => {
    setPickSearch(e.target.value);
  };
  const appsAmount = (e) => {
    setAppsNumber(e.target.value);
  };

  return (
    <div className="config-apps">
      <div>
        <input
          type="radio"
          id="js-search-filter"
          name="js-search-filter"
          value="1"
          checked={pickSearch == 1 ? true : false}
          onChange={handleRadioClick}
        />
        <label htmlFor="js-search-filter">Search filter</label>
      </div>
      <div>
        <input
          type="radio"
          id="js-search-enter"
          name="js-search-enter"
          value="2"
          checked={pickSearch == 2 ? true : false}
          onChange={handleRadioClick}
        />
        <label htmlFor="js-search-enter">Serch by enter/click button</label>
      </div>
      <div>
        <label htmlFor="js-search-enter">
          Applications to be displayed (0-18)
        </label>
        <input
          type="number"
          id="js-turn-onoff-apps"
          className="turn-onoff-apps"
          name="js-turn-onoff-apps"
          value={appsNumber}
          min="0"
          max="18"
          onChange={appsAmount}
        />
      </div>
      <div className="config-apps-button">
        <button
          className={btnDataSend ? "" : "infoSent"}
          onClick={() => {
            setTimeout(function () {
              toggleSearchAppsFn(pickSearch);
              appsToBeDisplayed(appsNumber);
              BtnDataSend(false);
              setTxtBtn("Done!");
              setTimeout(function () {
                BtnDataSend(true);
                setTxtBtn("Apply");
              }, 800);
            }, 100);
          }}
        >
          {txtBtn}
        </button>
      </div>
    </div>
  );
};

export const ConfigCustom = () => {
  return <div>Hello</div>;
};

export const ConfigSearch = () => {
  return <div>Hello</div>;
};
