import React from "react";
import "./Avatar.scss";

export default function Avatar() {
  return <div>Avatar</div>;
}
