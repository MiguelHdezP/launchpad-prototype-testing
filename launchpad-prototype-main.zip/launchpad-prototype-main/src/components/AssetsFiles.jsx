import Applications from "../assets/images/applications.png";
import MagnifyingGlass from "../assets/images/magnifying-glass.png";
import MagnifyingGlassWhite from "../assets/images/magnifying-glass-white.png";
import Calendar from "../assets/images/calendar.png";
import CalendarWhite from "../assets/images/calendawhite.png";
import ApplicationsBar from "../assets/images/applications-bar.png";
import CustomIcon from "../assets/images/custom.png";
import CustomIconWhite from "../assets/images/customwhite.png";
import Protocols from "../assets/images/protocols.png";
import Reports from "../assets/images/reports.png";
import Settings from "../assets/images/settings.png";

export {
  Applications,
  MagnifyingGlass,
  MagnifyingGlassWhite,
  Calendar,
  CalendarWhite,
  ApplicationsBar,
  CustomIcon,
  CustomIconWhite,
  Protocols,
  Reports,
  Settings,
};
